import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';
import 'package:myapp/light/splash-screen.dart';
// import 'package:myapp/light/onboarding.dart';
// import 'package:myapp/light/login.dart';
// import 'package:myapp/light/register.dart';
// import 'package:myapp/light/forgot-password.dart';
// import 'package:myapp/light/check-email.dart';
// import 'package:myapp/light/reset-password.dart';
// import 'package:myapp/light/home.dart';
// import 'package:myapp/light/wallets.dart';
// import 'package:myapp/light/new-transaction.dart';
// import 'package:myapp/light/profile.dart';
// import 'package:myapp/dark/splash-screen.dart';
// import 'package:myapp/dark/onboarding.dart';
// import 'package:myapp/dark/login.dart';
// import 'package:myapp/dark/register.dart';
// import 'package:myapp/dark/forgot-password.dart';
// import 'package:myapp/dark/check-email.dart';
// import 'package:myapp/dark/reset-password.dart';
// import 'package:myapp/dark/home.dart';
// import 'package:myapp/dark/wallets.dart';
// import 'package:myapp/dark/new-transaction.dart';
// import 'package:myapp/dark/profile.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
	@override
	Widget build(BuildContext context) {
	return MaterialApp(
		title: 'Flutter',
		debugShowCheckedModeBanner: false,
		scrollBehavior: MyCustomScrollBehavior(),
		theme: ThemeData(
		primarySwatch: Colors.blue,
		),
		home: Scaffold(
		body: SingleChildScrollView(
			child: Scene(),
		),
		),
	);
	}
}
