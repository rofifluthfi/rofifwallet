import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 375;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // walletsupk (12:540)
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xff000000),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // autogrouphzn43vx (VPEq7D3aGhF78GYvTPHzN4)
              padding: EdgeInsets.fromLTRB(139*fem, 50*fem, 138*fem, 59*fem),
              width: double.infinity,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // walletsaAC (12:541)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 340*fem),
                    child: Text(
                      'WALLETS',
                      textAlign: TextAlign.center,
                      style: SafeGoogleFont (
                        'Poppins',
                        fontSize: 12*ffem,
                        fontWeight: FontWeight.w700,
                        height: 1.5*ffem/fem,
                        letterSpacing: 1*fem,
                        color: Color(0xff7e7e7e),
                      ),
                    ),
                  ),
                  Container(
                    // creditcardsQC (12:553)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 14*fem),
                    width: 22*fem,
                    height: 16*fem,
                    child: Image.asset(
                      'assets/dark/images/credit-card.png',
                      width: 22*fem,
                      height: 16*fem,
                    ),
                  ),
                  Container(
                    // debitcardZnp (12:556)
                    margin: EdgeInsets.fromLTRB(1*fem, 0*fem, 0*fem, 10*fem),
                    child: Text(
                      'Debit Card',
                      style: SafeGoogleFont (
                        'Poppins',
                        fontSize: 14*ffem,
                        fontWeight: FontWeight.w700,
                        height: 1.5*ffem/fem,
                        letterSpacing: 1*fem,
                        color: Color(0xffffffff),
                      ),
                    ),
                  ),
                  Container(
                    // GhE (12:558)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 53*fem),
                    child: Text(
                      '\$ 1,845.36',
                      style: SafeGoogleFont (
                        'Poppins',
                        fontSize: 18*ffem,
                        fontWeight: FontWeight.w500,
                        height: 1.5*ffem/fem,
                        letterSpacing: 1*fem,
                        color: Color(0xff7e7e7e),
                      ),
                    ),
                  ),
                  Container(
                    // hashPWx (12:560)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 13*fem),
                    width: 16*fem,
                    height: 18*fem,
                    child: Image.asset(
                      'assets/dark/images/hash.png',
                      width: 16*fem,
                      height: 18*fem,
                    ),
                  ),
                  Container(
                    // cashv16 (12:557)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 1*fem, 10*fem),
                    child: Text(
                      'Cash',
                      textAlign: TextAlign.center,
                      style: SafeGoogleFont (
                        'Poppins',
                        fontSize: 14*ffem,
                        fontWeight: FontWeight.w700,
                        height: 1.5*ffem/fem,
                        letterSpacing: 1*fem,
                        color: Color(0xffffffff),
                      ),
                    ),
                  ),
                  Container(
                    // E1n (12:559)
                    margin: EdgeInsets.fromLTRB(1*fem, 0*fem, 0*fem, 59*fem),
                    child: Text(
                      '\$ 1,452.83',
                      style: SafeGoogleFont (
                        'Poppins',
                        fontSize: 18*ffem,
                        fontWeight: FontWeight.w500,
                        height: 1.5*ffem/fem,
                        letterSpacing: 1*fem,
                        color: Color(0xff7e7e7e),
                      ),
                    ),
                  ),
                  Container(
                    // chevronupLqW (12:565)
                    width: 12*fem,
                    height: 6*fem,
                    child: Image.asset(
                      'assets/dark/images/chevron-up.png',
                      width: 12*fem,
                      height: 6*fem,
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroupxiqys4k (VPEpuTt9FzVrU4GRHfXiQY)
              padding: EdgeInsets.fromLTRB(52*fem, 16*fem, 54*fem, 16*fem),
              width: double.infinity,
              decoration: BoxDecoration (
                color: Color(0xff000000),
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // activityaUx (12:543)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 107*fem, 0*fem),
                    width: 20*fem,
                    height: 18*fem,
                    child: Image.asset(
                      'assets/dark/images/activity-a5N.png',
                      width: 20*fem,
                      height: 18*fem,
                    ),
                  ),
                  Container(
                    // plussquareJA4 (12:545)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 108*fem, 0*fem),
                    width: 18*fem,
                    height: 18*fem,
                    child: Image.asset(
                      'assets/dark/images/plus-square-f8t.png',
                      width: 18*fem,
                      height: 18*fem,
                    ),
                  ),
                  Container(
                    // barchart21KN (12:549)
                    width: 16*fem,
                    height: 12*fem,
                    child: Image.asset(
                      'assets/dark/images/bar-chart-2-BfE.png',
                      width: 16*fem,
                      height: 12*fem,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
          );
  }
}