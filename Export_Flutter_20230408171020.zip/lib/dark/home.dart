import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 375;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // home3ur (12:489)
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xff000000),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // autogroupg8mn15z (VPEoaLRzV4oj3kwJRpG8mn)
              padding: EdgeInsets.fromLTRB(0*fem, 50*fem, 0*fem, 135*fem),
              width: double.infinity,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // cash7ui (12:490)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 1*fem, 14*fem),
                    child: Text(
                      'CASH',
                      textAlign: TextAlign.center,
                      style: SafeGoogleFont (
                        'Poppins',
                        fontSize: 12*ffem,
                        fontWeight: FontWeight.w700,
                        height: 1.5*ffem/fem,
                        letterSpacing: 1*fem,
                        color: Color(0xffffffff),
                      ),
                    ),
                  ),
                  Container(
                    // chevrondowndNG (12:491)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 1*fem, 59*fem),
                    width: 12*fem,
                    height: 6*fem,
                    child: Image.asset(
                      'assets/dark/images/chevron-down-RT6.png',
                      width: 12*fem,
                      height: 6*fem,
                    ),
                  ),
                  Container(
                    // 9Lc (12:493)
                    margin: EdgeInsets.fromLTRB(1*fem, 0*fem, 0*fem, 50*fem),
                    child: Text(
                      '\$ 1,452.83',
                      style: SafeGoogleFont (
                        'Poppins',
                        fontSize: 48*ffem,
                        fontWeight: FontWeight.w700,
                        height: 1.5*ffem/fem,
                        letterSpacing: 0.5*fem,
                        color: Color(0xffffffff),
                      ),
                    ),
                  ),
                  Container(
                    // autogroupjtcuFPe (VPEmmDnUMxQEGjzZP9JTCU)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 2*fem, 50*fem),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // november9zp (12:506)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 70*fem, 0*fem),
                          child: Text(
                            'NOVEMBER',
                            textAlign: TextAlign.right,
                            style: SafeGoogleFont (
                              'Poppins',
                              fontSize: 14*ffem,
                              fontWeight: FontWeight.w700,
                              height: 1.5*ffem/fem,
                              letterSpacing: 1*fem,
                              color: Color(0xff7e7e7e),
                            ),
                          ),
                        ),
                        Container(
                          // decemberruE (12:505)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 69*fem, 0*fem),
                          child: Text(
                            'DECEMBER',
                            style: SafeGoogleFont (
                              'Poppins',
                              fontSize: 14*ffem,
                              fontWeight: FontWeight.w700,
                              height: 1.5*ffem/fem,
                              letterSpacing: 1*fem,
                              color: Color(0xffffffff),
                            ),
                          ),
                        ),
                        Text(
                          // januaryaKS (12:507)
                          'JANUARY',
                          style: SafeGoogleFont (
                            'Poppins',
                            fontSize: 14*ffem,
                            fontWeight: FontWeight.w700,
                            height: 1.5*ffem/fem,
                            letterSpacing: 1*fem,
                            color: Color(0xff7e7e7e),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // dec7aG (12:514)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 261*fem, 20*fem),
                    child: Text(
                      '26 Dec',
                      style: SafeGoogleFont (
                        'Poppins',
                        fontSize: 14*ffem,
                        fontWeight: FontWeight.w700,
                        height: 1.5*ffem/fem,
                        letterSpacing: 1*fem,
                        color: Color(0xff7e7e7e),
                      ),
                    ),
                  ),
                  Container(
                    // autogroups9qzdoW (VPEmvYrG9MJgiys6n5s9qz)
                    margin: EdgeInsets.fromLTRB(35*fem, 0*fem, 31*fem, 20*fem),
                    width: double.infinity,
                    height: 45*fem,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // arrowdownmPv (12:516)
                          margin: EdgeInsets.fromLTRB(0*fem, 1*fem, 35*fem, 0*fem),
                          width: 14*fem,
                          height: 14*fem,
                          child: Image.asset(
                            'assets/dark/images/arrow-down-sJY.png',
                            width: 14*fem,
                            height: 14*fem,
                          ),
                        ),
                        Container(
                          // autogroupnfplg16 (VPEn4NxYpV8rVnimZENfpL)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 108*fem, 0*fem),
                          height: double.infinity,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                // oLc (12:508)
                                '\$ 12.35',
                                style: SafeGoogleFont (
                                  'Poppins',
                                  fontSize: 18*ffem,
                                  fontWeight: FontWeight.w700,
                                  height: 1.5*ffem/fem,
                                  letterSpacing: 1*fem,
                                  color: Color(0xffffffff),
                                ),
                              ),
                              Text(
                                // breakfastcoffee9QU (12:509)
                                'Breakfast & Coffee',
                                style: SafeGoogleFont (
                                  'Poppins',
                                  fontSize: 12*ffem,
                                  fontWeight: FontWeight.w500,
                                  height: 1.5*ffem/fem,
                                  letterSpacing: 1*fem,
                                  color: Color(0xff7e7e7e),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          // coffeeg9W (12:525)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 1*fem),
                          width: 21*fem,
                          height: 20*fem,
                          child: Image.asset(
                            'assets/dark/images/coffee-upk.png',
                            width: 21*fem,
                            height: 20*fem,
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // autogrouptbngzR6 (VPEnCD4qVcy2GbaSLNtBng)
                    margin: EdgeInsets.fromLTRB(35*fem, 0*fem, 34*fem, 50*fem),
                    width: double.infinity,
                    height: 45*fem,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // arrowdownvJk (12:522)
                          margin: EdgeInsets.fromLTRB(0*fem, 1*fem, 35*fem, 0*fem),
                          width: 14*fem,
                          height: 14*fem,
                          child: Image.asset(
                            'assets/dark/images/arrow-down-s2p.png',
                            width: 14*fem,
                            height: 14*fem,
                          ),
                        ),
                        Container(
                          // autogroupdlxqEqE (VPEnumhv6bxfLcGjztdLxQ)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 86*fem, 0*fem),
                          height: double.infinity,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                // 9xC (12:512)
                                '\$ 63.24',
                                style: SafeGoogleFont (
                                  'Poppins',
                                  fontSize: 18*ffem,
                                  fontWeight: FontWeight.w700,
                                  height: 1.5*ffem/fem,
                                  letterSpacing: 1*fem,
                                  color: Color(0xffffffff),
                                ),
                              ),
                              Text(
                                // thebookofworldWRN (12:513)
                                '1. The Book of World ...',
                                style: SafeGoogleFont (
                                  'Poppins',
                                  fontSize: 12*ffem,
                                  fontWeight: FontWeight.w500,
                                  height: 1.5*ffem/fem,
                                  letterSpacing: 1*fem,
                                  color: Color(0xff7e7e7e),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          // bookiXS (12:531)
                          margin: EdgeInsets.fromLTRB(0*fem, 1*fem, 0*fem, 0*fem),
                          width: 16*fem,
                          height: 20*fem,
                          child: Image.asset(
                            'assets/dark/images/book-kxY.png',
                            width: 16*fem,
                            height: 20*fem,
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // dec1Fe (12:515)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 261*fem, 20*fem),
                    child: Text(
                      '25 Dec',
                      style: SafeGoogleFont (
                        'Poppins',
                        fontSize: 14*ffem,
                        fontWeight: FontWeight.w700,
                        height: 1.5*ffem/fem,
                        letterSpacing: 1*fem,
                        color: Color(0xff7e7e7e),
                      ),
                    ),
                  ),
                  Container(
                    // autogroupz3m2GxG (VPEo5WvgJHwXkusR1Yz3M2)
                    margin: EdgeInsets.fromLTRB(35*fem, 0*fem, 32*fem, 0*fem),
                    width: double.infinity,
                    height: 45*fem,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // arrowdownMD2 (12:519)
                          margin: EdgeInsets.fromLTRB(0*fem, 1*fem, 35*fem, 0*fem),
                          width: 14*fem,
                          height: 14*fem,
                          child: Image.asset(
                            'assets/dark/images/arrow-down.png',
                            width: 14*fem,
                            height: 14*fem,
                          ),
                        ),
                        Container(
                          // autogrouptxynEXi (VPEoCbZDRJEZC1DeUoTxyn)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 130*fem, 0*fem),
                          height: double.infinity,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                // WEL (12:510)
                                '\$ 100.00',
                                style: SafeGoogleFont (
                                  'Poppins',
                                  fontSize: 18*ffem,
                                  fontWeight: FontWeight.w700,
                                  height: 1.5*ffem/fem,
                                  letterSpacing: 1*fem,
                                  color: Color(0xffffffff),
                                ),
                              ),
                              Text(
                                // christmasgifts1gt (12:511)
                                'Christmas Gifts',
                                style: SafeGoogleFont (
                                  'Poppins',
                                  fontSize: 12*ffem,
                                  fontWeight: FontWeight.w500,
                                  height: 1.5*ffem/fem,
                                  letterSpacing: 1*fem,
                                  color: Color(0xff7e7e7e),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          // gift8Wc (12:534)
                          margin: EdgeInsets.fromLTRB(0*fem, 1*fem, 0*fem, 0*fem),
                          width: 20*fem,
                          height: 20*fem,
                          child: Image.asset(
                            'assets/dark/images/gift.png',
                            width: 20*fem,
                            height: 20*fem,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroupksqrPxL (VPEoLvefoBkpXHkGoDKsqr)
              padding: EdgeInsets.fromLTRB(52*fem, 16*fem, 54*fem, 16*fem),
              width: double.infinity,
              decoration: BoxDecoration (
                color: Color(0xff000000),
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // activityteC (12:495)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 107*fem, 0*fem),
                    width: 20*fem,
                    height: 18*fem,
                    child: Image.asset(
                      'assets/dark/images/activity-XVA.png',
                      width: 20*fem,
                      height: 18*fem,
                    ),
                  ),
                  Container(
                    // plussquarecaC (12:497)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 108*fem, 0*fem),
                    width: 18*fem,
                    height: 18*fem,
                    child: Image.asset(
                      'assets/dark/images/plus-square-g9e.png',
                      width: 18*fem,
                      height: 18*fem,
                    ),
                  ),
                  Container(
                    // barchart26EU (12:501)
                    width: 16*fem,
                    height: 12*fem,
                    child: Image.asset(
                      'assets/dark/images/bar-chart-2-TBe.png',
                      width: 16*fem,
                      height: 12*fem,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
          );
  }
}