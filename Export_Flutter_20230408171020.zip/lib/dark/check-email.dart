import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 375;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // checkemailSZW (12:401)
        padding: EdgeInsets.fromLTRB(20*fem, 70*fem, 20*fem, 55*fem),
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xff000000),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // loginx24 (12:404)
              margin: EdgeInsets.fromLTRB(2*fem, 0*fem, 0*fem, 30*fem),
              child: Text(
                'CHECK YOUR EMAIL',
                style: SafeGoogleFont (
                  'Poppins',
                  fontSize: 12*ffem,
                  fontWeight: FontWeight.w700,
                  height: 1.5*ffem/fem,
                  letterSpacing: 2*fem,
                  color: Color(0xff7e7e7e),
                ),
              ),
            ),
            Container(
              // undrawopenedrei38e11TUc (14:205)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 1*fem, 262*fem),
              width: 200*fem,
              height: 176*fem,
              child: Image.asset(
                'assets/dark/images/undrawopenedrei38e1-1.png',
                width: 200*fem,
                height: 176*fem,
              ),
            ),
            Container(
              // checkyouremailwevesentyoualink (12:408)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 50*fem),
              constraints: BoxConstraints (
                maxWidth: 320*fem,
              ),
              child: Text(
                'Check your email! We’ve sent you a link to reset your password.',
                textAlign: TextAlign.center,
                style: SafeGoogleFont (
                  'Poppins',
                  fontSize: 14*ffem,
                  fontWeight: FontWeight.w500,
                  height: 1.5*ffem/fem,
                  letterSpacing: 2*fem,
                  color: Color(0xff7e7e7e),
                ),
              ),
            ),
            Container(
              // autogroupqujcPFn (VPEkkzxV1CN4YAF15oqUJc)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 55*fem),
              width: double.infinity,
              height: 40*fem,
              decoration: BoxDecoration (
                color: Color(0xffffffff),
                borderRadius: BorderRadius.circular(5*fem),
              ),
              child: Center(
                child: Center(
                  child: Text(
                    'Open Email App',
                    textAlign: TextAlign.center,
                    style: SafeGoogleFont (
                      'Poppins',
                      fontSize: 12*ffem,
                      fontWeight: FontWeight.w500,
                      height: 1.5*ffem/fem,
                      letterSpacing: 2*fem,
                      color: Color(0xff000000),
                    ),
                  ),
                ),
              ),
            ),
            Container(
              // arrowleftdvp (12:405)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 1*fem, 0*fem),
              width: 14*fem,
              height: 14*fem,
              child: Image.asset(
                'assets/dark/images/arrow-left-JKi.png',
                width: 14*fem,
                height: 14*fem,
              ),
            ),
          ],
        ),
      ),
          );
  }
}