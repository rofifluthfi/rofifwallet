import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 375;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // resetpasswordx3J (12:420)
        padding: EdgeInsets.fromLTRB(19*fem, 70*fem, 20*fem, 55*fem),
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xff000000),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // loginEWc (12:423)
              margin: EdgeInsets.fromLTRB(4*fem, 0*fem, 0*fem, 30*fem),
              child: Text(
                'RESET PASSWORD',
                style: SafeGoogleFont (
                  'Poppins',
                  fontSize: 12*ffem,
                  fontWeight: FontWeight.w700,
                  height: 1.5*ffem/fem,
                  letterSpacing: 2*fem,
                  color: Color(0xff7e7e7e),
                ),
              ),
            ),
            Container(
              // undrawmypasswordd6kg11wA8 (14:163)
              margin: EdgeInsets.fromLTRB(2*fem, 0*fem, 0*fem, 180*fem),
              width: 200*fem,
              height: 166*fem,
              child: Image.asset(
                'assets/dark/images/undrawmypasswordd6kg1-1.png',
                width: 200*fem,
                height: 166*fem,
              ),
            ),
            Container(
              // autogroupcu92CLx (VPEm3AAE4DiVeFdJBNCu92)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 1*fem, 6*fem),
              width: 335*fem,
              height: 72*fem,
              child: Stack(
                children: [
                  Positioned(
                    // loginKRa (12:470)
                    left: 22.5*fem,
                    top: 8*fem,
                    child: Align(
                      child: SizedBox(
                        width: 75*fem,
                        height: 15*fem,
                        child: Text(
                          'PASSWORD',
                          textAlign: TextAlign.center,
                          style: SafeGoogleFont (
                            'Poppins',
                            fontSize: 10*ffem,
                            fontWeight: FontWeight.w700,
                            height: 1.5*ffem/fem,
                            letterSpacing: 2*fem,
                            color: Color(0xff7e7e7e),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // QT2 (12:472)
                    left: 23*fem,
                    top: 0*fem,
                    child: Align(
                      child: SizedBox(
                        width: 75*fem,
                        height: 72*fem,
                        child: Text(
                          '·······',
                          style: SafeGoogleFont (
                            'Poppins',
                            fontSize: 48*ffem,
                            fontWeight: FontWeight.w400,
                            height: 1.5*ffem/fem,
                            letterSpacing: 0.5*fem,
                            color: Color(0xffffffff),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // subtract7MS (12:478)
                    left: 0*fem,
                    top: 16*fem,
                    child: Align(
                      child: SizedBox(
                        width: 335*fem,
                        height: 40*fem,
                        child: Image.asset(
                          'assets/dark/images/subtract-c9E.png',
                          width: 335*fem,
                          height: 40*fem,
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // eye1Sp (12:483)
                    left: 297.75*fem,
                    top: 30*fem,
                    child: Align(
                      child: SizedBox(
                        width: 16.5*fem,
                        height: 12*fem,
                        child: Image.asset(
                          'assets/dark/images/eye-d3W.png',
                          width: 16.5*fem,
                          height: 12*fem,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroupa2uyXAG (VPEmA58NcJn9tX5soXa2UY)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 1*fem, 34*fem),
              width: 335*fem,
              height: 72*fem,
              child: Stack(
                children: [
                  Positioned(
                    // loginT3v (12:469)
                    left: 29*fem,
                    top: 8*fem,
                    child: Align(
                      child: SizedBox(
                        width: 62*fem,
                        height: 15*fem,
                        child: Text(
                          'CONFIRM',
                          textAlign: TextAlign.center,
                          style: SafeGoogleFont (
                            'Poppins',
                            fontSize: 10*ffem,
                            fontWeight: FontWeight.w700,
                            height: 1.5*ffem/fem,
                            letterSpacing: 2*fem,
                            color: Color(0xff7e7e7e),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // Z6x (12:471)
                    left: 23*fem,
                    top: 0*fem,
                    child: Align(
                      child: SizedBox(
                        width: 75*fem,
                        height: 72*fem,
                        child: Text(
                          '·······',
                          style: SafeGoogleFont (
                            'Poppins',
                            fontSize: 48*ffem,
                            fontWeight: FontWeight.w400,
                            height: 1.5*ffem/fem,
                            letterSpacing: 0.5*fem,
                            color: Color(0xffffffff),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // subtractR9A (12:473)
                    left: 0*fem,
                    top: 16*fem,
                    child: Align(
                      child: SizedBox(
                        width: 335*fem,
                        height: 40*fem,
                        child: Image.asset(
                          'assets/dark/images/subtract.png',
                          width: 335*fem,
                          height: 40*fem,
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // eyeLmv (12:486)
                    left: 297.75*fem,
                    top: 30*fem,
                    child: Align(
                      child: SizedBox(
                        width: 16.5*fem,
                        height: 12*fem,
                        child: Image.asset(
                          'assets/dark/images/eye-UNt.png',
                          width: 16.5*fem,
                          height: 12*fem,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroupnmbeEsJ (VPEmG4xP3M5JcF9NGhnmBE)
              margin: EdgeInsets.fromLTRB(1*fem, 0*fem, 0*fem, 55*fem),
              width: 335*fem,
              height: 40*fem,
              decoration: BoxDecoration (
                color: Color(0xffffffff),
                borderRadius: BorderRadius.circular(5*fem),
              ),
              child: Center(
                child: Center(
                  child: Text(
                    'Open Email App',
                    textAlign: TextAlign.center,
                    style: SafeGoogleFont (
                      'Poppins',
                      fontSize: 12*ffem,
                      fontWeight: FontWeight.w500,
                      height: 1.5*ffem/fem,
                      letterSpacing: 2*fem,
                      color: Color(0xff000000),
                    ),
                  ),
                ),
              ),
            ),
            Container(
              // arrowleftJsA (12:424)
              width: 14*fem,
              height: 14*fem,
              child: Image.asset(
                'assets/dark/images/arrow-left-u76.png',
                width: 14*fem,
                height: 14*fem,
              ),
            ),
          ],
        ),
      ),
          );
  }
}