import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 375;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // onboarding6Ak (12:101)
        padding: EdgeInsets.fromLTRB(20*fem, 72*fem, 20*fem, 50*fem),
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xff000000),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // rofifwalletDWG (12:180)
              margin: EdgeInsets.fromLTRB(2*fem, 0*fem, 0*fem, 144.02*fem),
              child: Text(
                'ROFIF - WALLET',
                style: SafeGoogleFont (
                  'Poppins',
                  fontSize: 12*ffem,
                  fontWeight: FontWeight.w700,
                  height: 1.5*ffem/fem,
                  letterSpacing: 2*fem,
                  color: Color(0xff7e7e7e),
                ),
              ),
            ),
            Container(
              // undrawfinance0bdk21WkG (12:668)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 70.01*fem),
              width: 335*fem,
              height: 192.96*fem,
              child: Image.asset(
                'assets/dark/images/undrawfinance0bdk2-1.png',
                width: 335*fem,
                height: 192.96*fem,
              ),
            ),
            Container(
              // caralebihbaikdanmudahuntukmela (12:177)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 144*fem),
              constraints: BoxConstraints (
                maxWidth: 310*fem,
              ),
              child: Text(
                'Cara Lebih Baik Dan  Mudah\nUntuk Melacak Pendapatan\nDan Pengeluaran Anda',
                textAlign: TextAlign.center,
                style: SafeGoogleFont (
                  'Poppins',
                  fontSize: 18*ffem,
                  fontWeight: FontWeight.w700,
                  height: 1.5*ffem/fem,
                  letterSpacing: 2*fem,
                  color: Color(0xffffffff),
                ),
              ),
            ),
            Container(
              // autogroupqabsQz4 (VPEiz3v2G1xKBssk3HQAbS)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 0*fem),
              width: double.infinity,
              height: 40*fem,
              decoration: BoxDecoration (
                color: Color(0xffffffff),
                borderRadius: BorderRadius.circular(5*fem),
              ),
              child: Center(
                child: Center(
                  child: Text(
                    'Get Started',
                    textAlign: TextAlign.center,
                    style: SafeGoogleFont (
                      'Poppins',
                      fontSize: 12*ffem,
                      fontWeight: FontWeight.w500,
                      height: 1.5*ffem/fem,
                      letterSpacing: 2*fem,
                      color: Color(0xff000000),
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
          );
  }
}