import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 375;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // resetpasswordr9v (8:718)
        padding: EdgeInsets.fromLTRB(19*fem, 70*fem, 20*fem, 55*fem),
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xffffffff),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // login8t8 (8:721)
              margin: EdgeInsets.fromLTRB(4*fem, 0*fem, 0*fem, 30*fem),
              child: Text(
                'RESET PASSWORD',
                style: SafeGoogleFont (
                  'Poppins',
                  fontSize: 12*ffem,
                  fontWeight: FontWeight.w700,
                  height: 1.5*ffem/fem,
                  letterSpacing: 2*fem,
                  color: Color(0xff7e7e7e),
                ),
              ),
            ),
            Container(
              // undrawmypasswordd6kg1FC4 (8:774)
              margin: EdgeInsets.fromLTRB(2*fem, 0*fem, 0*fem, 180*fem),
              width: 200*fem,
              height: 166*fem,
              child: Image.asset(
                'assets/light/images/undrawmypasswordd6kg-1.png',
                width: 200*fem,
                height: 166*fem,
              ),
            ),
            Container(
              // autogroup7ccpunQ (VPEcn4bBniyvqYNe5d7CCp)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 1*fem, 6*fem),
              width: 335*fem,
              height: 72*fem,
              child: Stack(
                children: [
                  Positioned(
                    // loginRVr (8:834)
                    left: 22.5*fem,
                    top: 8*fem,
                    child: Align(
                      child: SizedBox(
                        width: 75*fem,
                        height: 15*fem,
                        child: Text(
                          'PASSWORD',
                          textAlign: TextAlign.center,
                          style: SafeGoogleFont (
                            'Poppins',
                            fontSize: 10*ffem,
                            fontWeight: FontWeight.w700,
                            height: 1.5*ffem/fem,
                            letterSpacing: 2*fem,
                            color: Color(0xff7e7e7e),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // K5S (8:835)
                    left: 23*fem,
                    top: 0*fem,
                    child: Align(
                      child: SizedBox(
                        width: 75*fem,
                        height: 72*fem,
                        child: Text(
                          '·······',
                          style: SafeGoogleFont (
                            'Poppins',
                            fontSize: 48*ffem,
                            fontWeight: FontWeight.w400,
                            height: 1.5*ffem/fem,
                            letterSpacing: 0.5*fem,
                            color: Color(0xff000000),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // subtractC9E (8:836)
                    left: 0*fem,
                    top: 16*fem,
                    child: Align(
                      child: SizedBox(
                        width: 335*fem,
                        height: 40*fem,
                        child: Image.asset(
                          'assets/light/images/subtract-SHv.png',
                          width: 335*fem,
                          height: 40*fem,
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // eyeidN (8:850)
                    left: 297.75*fem,
                    top: 30*fem,
                    child: Align(
                      child: SizedBox(
                        width: 16.5*fem,
                        height: 12*fem,
                        child: Image.asset(
                          'assets/light/images/eye-DzG.png',
                          width: 16.5*fem,
                          height: 12*fem,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroupcibabx4 (VPEcuthUTrp6cMEJrmciBA)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 1*fem, 34*fem),
              width: 335*fem,
              height: 72*fem,
              child: Stack(
                children: [
                  Positioned(
                    // login8SC (8:827)
                    left: 29*fem,
                    top: 8*fem,
                    child: Align(
                      child: SizedBox(
                        width: 62*fem,
                        height: 15*fem,
                        child: Text(
                          'CONFIRM',
                          textAlign: TextAlign.center,
                          style: SafeGoogleFont (
                            'Poppins',
                            fontSize: 10*ffem,
                            fontWeight: FontWeight.w700,
                            height: 1.5*ffem/fem,
                            letterSpacing: 2*fem,
                            color: Color(0xff7e7e7e),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // zzC (8:828)
                    left: 23*fem,
                    top: 0*fem,
                    child: Align(
                      child: SizedBox(
                        width: 75*fem,
                        height: 72*fem,
                        child: Text(
                          '·······',
                          style: SafeGoogleFont (
                            'Poppins',
                            fontSize: 48*ffem,
                            fontWeight: FontWeight.w400,
                            height: 1.5*ffem/fem,
                            letterSpacing: 0.5*fem,
                            color: Color(0xff000000),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // subtractVvx (8:829)
                    left: 0*fem,
                    top: 16*fem,
                    child: Align(
                      child: SizedBox(
                        width: 335*fem,
                        height: 40*fem,
                        child: Image.asset(
                          'assets/light/images/subtract-7Xe.png',
                          width: 335*fem,
                          height: 40*fem,
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // eyed1a (8:853)
                    left: 297.75*fem,
                    top: 30*fem,
                    child: Align(
                      child: SizedBox(
                        width: 16.5*fem,
                        height: 12*fem,
                        child: Image.asset(
                          'assets/light/images/eye-bRa.png',
                          width: 16.5*fem,
                          height: 12*fem,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroupieac8yv (VPEd1is6Kyst9FQ9Urieac)
              margin: EdgeInsets.fromLTRB(1*fem, 0*fem, 0*fem, 55*fem),
              width: 335*fem,
              height: 40*fem,
              decoration: BoxDecoration (
                color: Color(0xff000000),
                borderRadius: BorderRadius.circular(5*fem),
              ),
              child: Center(
                child: Center(
                  child: Text(
                    'Open Email App',
                    textAlign: TextAlign.center,
                    style: SafeGoogleFont (
                      'Poppins',
                      fontSize: 12*ffem,
                      fontWeight: FontWeight.w500,
                      height: 1.5*ffem/fem,
                      letterSpacing: 2*fem,
                      color: Color(0xffffffff),
                    ),
                  ),
                ),
              ),
            ),
            Container(
              // arrowleftnYg (8:770)
              width: 14*fem,
              height: 14*fem,
              child: Image.asset(
                'assets/light/images/arrow-left-5Hr.png',
                width: 14*fem,
                height: 14*fem,
              ),
            ),
          ],
        ),
      ),
          );
  }
}