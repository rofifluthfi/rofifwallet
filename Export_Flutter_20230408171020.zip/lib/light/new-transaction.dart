import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 375;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // newtransactionqyA (8:1002)
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xffffffff),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // autogroupfxdinNc (VPEhSBL74t8jzQvCwBfXDi)
              padding: EdgeInsets.fromLTRB(20*fem, 50*fem, 20*fem, 50*fem),
              width: double.infinity,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // newtransactionWJc (8:1014)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 1*fem, 30*fem),
                    child: Text(
                      'NEW TRANSACTION',
                      textAlign: TextAlign.center,
                      style: SafeGoogleFont (
                        'Poppins',
                        fontSize: 12*ffem,
                        fontWeight: FontWeight.w700,
                        height: 1.5*ffem/fem,
                        letterSpacing: 1*fem,
                        color: Color(0xff7e7e7e),
                      ),
                    ),
                  ),
                  Container(
                    // undrawpayonlineb1hk1bax (12:38)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 1*fem, 64*fem),
                    width: 200*fem,
                    height: 156*fem,
                    child: Image.asset(
                      'assets/light/images/undrawpayonlineb1hk-1.png',
                      width: 200*fem,
                      height: 156*fem,
                    ),
                  ),
                  Container(
                    // autogroupdtheFfW (VPEgr2eLijtrj9MSS6dtHE)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 30*fem),
                    width: double.infinity,
                    height: 48*fem,
                    child: Stack(
                      children: [
                        Positioned(
                          // loginA1n (12:11)
                          left: 21.5*fem,
                          top: 0*fem,
                          child: Align(
                            child: SizedBox(
                              width: 57*fem,
                              height: 15*fem,
                              child: Text(
                                'AMOUNT',
                                textAlign: TextAlign.center,
                                style: SafeGoogleFont (
                                  'Poppins',
                                  fontSize: 10*ffem,
                                  fontWeight: FontWeight.w700,
                                  height: 1.5*ffem/fem,
                                  letterSpacing: 2*fem,
                                  color: Color(0xff7e7e7e),
                                ),
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // useremailcom3rG (12:15)
                          left: 26*fem,
                          top: 17.5*fem,
                          child: Align(
                            child: SizedBox(
                              width: 126*fem,
                              height: 21*fem,
                              child: Text(
                                'user@email.com',
                                style: SafeGoogleFont (
                                  'Poppins',
                                  fontSize: 14*ffem,
                                  fontWeight: FontWeight.w400,
                                  height: 1.5*ffem/fem,
                                  letterSpacing: 0.5*fem,
                                  color: Color(0xff000000),
                                ),
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // subtractZ3v (12:17)
                          left: 0*fem,
                          top: 8*fem,
                          child: Align(
                            child: SizedBox(
                              width: 335*fem,
                              height: 40*fem,
                              child: Image.asset(
                                'assets/light/images/subtract-LpY.png',
                                width: 335*fem,
                                height: 40*fem,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // autogrouppbhsFxL (VPEgz7FDFFa5HC3ayspbhS)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 30*fem),
                    width: double.infinity,
                    height: 48*fem,
                    child: Stack(
                      children: [
                        Positioned(
                          // loginC6t (12:18)
                          left: 24*fem,
                          top: 0*fem,
                          child: Align(
                            child: SizedBox(
                              width: 72*fem,
                              height: 15*fem,
                              child: Text(
                                'CATEGORY',
                                textAlign: TextAlign.center,
                                style: SafeGoogleFont (
                                  'Poppins',
                                  fontSize: 10*ffem,
                                  fontWeight: FontWeight.w700,
                                  height: 1.5*ffem/fem,
                                  letterSpacing: 2*fem,
                                  color: Color(0xff7e7e7e),
                                ),
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // foodanddrinkssD2 (12:19)
                          left: 26*fem,
                          top: 17.5*fem,
                          child: Align(
                            child: SizedBox(
                              width: 120*fem,
                              height: 21*fem,
                              child: Text(
                                'Food and Drinks',
                                style: SafeGoogleFont (
                                  'Poppins',
                                  fontSize: 14*ffem,
                                  fontWeight: FontWeight.w400,
                                  height: 1.5*ffem/fem,
                                  letterSpacing: 0.5*fem,
                                  color: Color(0xff000000),
                                ),
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // subtract9gL (12:26)
                          left: 0*fem,
                          top: 8*fem,
                          child: Align(
                            child: SizedBox(
                              width: 335*fem,
                              height: 40*fem,
                              child: Image.asset(
                                'assets/light/images/subtract-U48.png',
                                width: 335*fem,
                                height: 40*fem,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // autogrouprkdsgRN (VPEh7MY8wB6Tu7HUJDRKdS)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 50*fem),
                    width: double.infinity,
                    height: 148*fem,
                    child: Stack(
                      children: [
                        Positioned(
                          // loginQMN (12:27)
                          left: 20.5*fem,
                          top: 0*fem,
                          child: Align(
                            child: SizedBox(
                              width: 89*fem,
                              height: 15*fem,
                              child: Text(
                                'DESCRIPTION',
                                textAlign: TextAlign.center,
                                style: SafeGoogleFont (
                                  'Poppins',
                                  fontSize: 10*ffem,
                                  fontWeight: FontWeight.w700,
                                  height: 1.5*ffem/fem,
                                  letterSpacing: 2*fem,
                                  color: Color(0xff7e7e7e),
                                ),
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // descriptionHvx (12:28)
                          left: 26*fem,
                          top: 17.5*fem,
                          child: Align(
                            child: SizedBox(
                              width: 85*fem,
                              height: 21*fem,
                              child: Text(
                                'Description',
                                style: SafeGoogleFont (
                                  'Poppins',
                                  fontSize: 14*ffem,
                                  fontWeight: FontWeight.w400,
                                  height: 1.5*ffem/fem,
                                  letterSpacing: 0.5*fem,
                                  color: Color(0xff000000),
                                ),
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // subtractBmS (12:37)
                          left: 0*fem,
                          top: 8*fem,
                          child: Align(
                            child: SizedBox(
                              width: 335*fem,
                              height: 140*fem,
                              child: Image.asset(
                                'assets/light/images/subtract-nCx.png',
                                width: 335*fem,
                                height: 140*fem,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // autogroupjghnhjn (VPEhCmYnP15qTwjBJajGHn)
                    width: double.infinity,
                    height: 40*fem,
                    decoration: BoxDecoration (
                      color: Color(0xff000000),
                      borderRadius: BorderRadius.circular(5*fem),
                    ),
                    child: Center(
                      child: Center(
                        child: Text(
                          'Add Transaction',
                          textAlign: TextAlign.center,
                          style: SafeGoogleFont (
                            'Poppins',
                            fontSize: 12*ffem,
                            fontWeight: FontWeight.w500,
                            height: 1.5*ffem/fem,
                            letterSpacing: 2*fem,
                            color: Color(0xffffffff),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogrouptdtvPMi (VPEhHMFUzEvP6eid5WTDTv)
              padding: EdgeInsets.fromLTRB(52*fem, 16*fem, 54*fem, 16*fem),
              width: double.infinity,
              decoration: BoxDecoration (
                color: Color(0xffffffff),
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // activity61E (8:1004)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 107*fem, 0*fem),
                    width: 20*fem,
                    height: 18*fem,
                    child: Image.asset(
                      'assets/light/images/activity.png',
                      width: 20*fem,
                      height: 18*fem,
                    ),
                  ),
                  Container(
                    // plussquareD5r (8:1006)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 108*fem, 0*fem),
                    width: 18*fem,
                    height: 18*fem,
                    child: Image.asset(
                      'assets/light/images/plus-square-A6c.png',
                      width: 18*fem,
                      height: 18*fem,
                    ),
                  ),
                  Container(
                    // barchart2j4C (8:1010)
                    width: 16*fem,
                    height: 12*fem,
                    child: Image.asset(
                      'assets/light/images/bar-chart-2-yVr.png',
                      width: 16*fem,
                      height: 12*fem,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
          );
  }
}