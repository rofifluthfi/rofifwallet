import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 375;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // splashscreenidN (2:0)
        padding: EdgeInsets.fromLTRB(104*fem, 397*fem, 102*fem, 50*fem),
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xffffffff),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // rofifwalletLHN (6:2)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 329*fem),
              child: Text(
                'ROFIF - WALLET',
                style: SafeGoogleFont (
                  'Poppins',
                  fontSize: 12*ffem,
                  fontWeight: FontWeight.w700,
                  height: 1.5*ffem/fem,
                  letterSpacing: 2*fem,
                  color: Color(0xff000000),
                ),
              ),
            ),
            Text(
              // aminimalwalletappaxQ (6:4)
              'A minimal wallet app',
              style: SafeGoogleFont (
                'Poppins',
                fontSize: 12*ffem,
                fontWeight: FontWeight.w500,
                height: 1.5*ffem/fem,
                letterSpacing: 2*fem,
                color: Color(0xff7e7e7e),
              ),
            ),
          ],
        ),
      ),
          );
  }
}