import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 375;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // onboardingbuS (8:156)
        padding: EdgeInsets.fromLTRB(20*fem, 72*fem, 20*fem, 50*fem),
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xffffffff),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // rofifwalletJJ4 (8:235)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 32*fem, 144.02*fem),
              child: Text(
                'ROFIF - WALLET',
                style: SafeGoogleFont (
                  'Poppins',
                  fontSize: 12*ffem,
                  fontWeight: FontWeight.w700,
                  height: 1.5*ffem/fem,
                  letterSpacing: 2*fem,
                  color: Color(0xff7e7e7e),
                ),
              ),
            ),
            Container(
              // undrawfinance0bdk1YiC (8:158)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 70.01*fem),
              width: 335*fem,
              height: 192.96*fem,
              child: Image.asset(
                'assets/light/images/undrawfinance0bdk-1.png',
                width: 335*fem,
                height: 192.96*fem,
              ),
            ),
            Container(
              // caralebihbaikdanmudahuntukmela (8:233)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 144*fem),
              constraints: BoxConstraints (
                maxWidth: 306*fem,
              ),
              child: Text(
                'Cara Lebih Baik Dan Mudah\nUntuk Melacak Pendapatan\nDan Pengeluaran Anda ',
                textAlign: TextAlign.center,
                style: SafeGoogleFont (
                  'Poppins',
                  fontSize: 18*ffem,
                  fontWeight: FontWeight.w700,
                  height: 1.5*ffem/fem,
                  letterSpacing: 2*fem,
                  color: Color(0xff000000),
                ),
              ),
            ),
            Container(
              // autogroupw2ppbpt (VPEaSo9EwVsKH5Enqyw2pp)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 0*fem),
              width: double.infinity,
              height: 40*fem,
              decoration: BoxDecoration (
                color: Color(0xff000000),
                borderRadius: BorderRadius.circular(5*fem),
              ),
              child: Center(
                child: Center(
                  child: Text(
                    'Get Started',
                    textAlign: TextAlign.center,
                    style: SafeGoogleFont (
                      'Poppins',
                      fontSize: 12*ffem,
                      fontWeight: FontWeight.w500,
                      height: 1.5*ffem/fem,
                      letterSpacing: 2*fem,
                      color: Color(0xffffffff),
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
          );
  }
}