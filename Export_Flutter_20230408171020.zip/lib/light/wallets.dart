import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 375;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // walletsxfr (8:930)
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xffffffff),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // autogroupnekggrk (VPEgFYdoEmCF6E1NEqNekG)
              padding: EdgeInsets.fromLTRB(139*fem, 50*fem, 138*fem, 59*fem),
              width: double.infinity,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // walletsoAg (8:931)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 340*fem),
                    child: Text(
                      'WALLETS',
                      textAlign: TextAlign.center,
                      style: SafeGoogleFont (
                        'Poppins',
                        fontSize: 12*ffem,
                        fontWeight: FontWeight.w700,
                        height: 1.5*ffem/fem,
                        letterSpacing: 1*fem,
                        color: Color(0xff7e7e7e),
                      ),
                    ),
                  ),
                  Container(
                    // creditcarduDi (8:984)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 14*fem),
                    width: 22*fem,
                    height: 16*fem,
                    child: Image.asset(
                      'assets/light/images/credit-card-Uzc.png',
                      width: 22*fem,
                      height: 16*fem,
                    ),
                  ),
                  Container(
                    // debitcardpba (8:992)
                    margin: EdgeInsets.fromLTRB(1*fem, 0*fem, 0*fem, 10*fem),
                    child: Text(
                      'Debit Card',
                      style: SafeGoogleFont (
                        'Poppins',
                        fontSize: 14*ffem,
                        fontWeight: FontWeight.w700,
                        height: 1.5*ffem/fem,
                        letterSpacing: 1*fem,
                        color: Color(0xff000000),
                      ),
                    ),
                  ),
                  Container(
                    // 8MN (8:993)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 53*fem),
                    child: Text(
                      '\$ 1,845.36',
                      style: SafeGoogleFont (
                        'Poppins',
                        fontSize: 18*ffem,
                        fontWeight: FontWeight.w500,
                        height: 1.5*ffem/fem,
                        letterSpacing: 1*fem,
                        color: Color(0xff7e7e7e),
                      ),
                    ),
                  ),
                  Container(
                    // hashrHN (8:987)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 13*fem),
                    width: 16*fem,
                    height: 18*fem,
                    child: Image.asset(
                      'assets/light/images/hash-9GC.png',
                      width: 16*fem,
                      height: 18*fem,
                    ),
                  ),
                  Container(
                    // cashWcp (8:998)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 1*fem, 10*fem),
                    child: Text(
                      'Cash',
                      textAlign: TextAlign.center,
                      style: SafeGoogleFont (
                        'Poppins',
                        fontSize: 14*ffem,
                        fontWeight: FontWeight.w700,
                        height: 1.5*ffem/fem,
                        letterSpacing: 1*fem,
                        color: Color(0xff000000),
                      ),
                    ),
                  ),
                  Container(
                    // RDz (8:999)
                    margin: EdgeInsets.fromLTRB(1*fem, 0*fem, 0*fem, 59*fem),
                    child: Text(
                      '\$ 1,452.83',
                      style: SafeGoogleFont (
                        'Poppins',
                        fontSize: 18*ffem,
                        fontWeight: FontWeight.w500,
                        height: 1.5*ffem/fem,
                        letterSpacing: 1*fem,
                        color: Color(0xff7e7e7e),
                      ),
                    ),
                  ),
                  Container(
                    // chevronupY3i (8:1000)
                    width: 12*fem,
                    height: 6*fem,
                    child: Image.asset(
                      'assets/light/images/chevron-up-MKn.png',
                      width: 12*fem,
                      height: 6*fem,
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroupcngx5JY (VPEg4dnK4ebpN9B8JZCNGx)
              padding: EdgeInsets.fromLTRB(52*fem, 16*fem, 54*fem, 16*fem),
              width: double.infinity,
              decoration: BoxDecoration (
                color: Color(0xffffffff),
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // activityC8G (8:936)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 107*fem, 0*fem),
                    width: 20*fem,
                    height: 18*fem,
                    child: Image.asset(
                      'assets/light/images/activity-bGC.png',
                      width: 20*fem,
                      height: 18*fem,
                    ),
                  ),
                  Container(
                    // plussquare6UY (8:938)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 108*fem, 0*fem),
                    width: 18*fem,
                    height: 18*fem,
                    child: Image.asset(
                      'assets/light/images/plus-square.png',
                      width: 18*fem,
                      height: 18*fem,
                    ),
                  ),
                  Container(
                    // barchart215i (8:942)
                    width: 16*fem,
                    height: 12*fem,
                    child: Image.asset(
                      'assets/light/images/bar-chart-2-hyJ.png',
                      width: 16*fem,
                      height: 12*fem,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
          );
  }
}