import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 375;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // forgotpassword8xp (8:502)
        padding: EdgeInsets.fromLTRB(20*fem, 70*fem, 20*fem, 55*fem),
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xffffffff),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // logindeg (8:505)
              margin: EdgeInsets.fromLTRB(1*fem, 0*fem, 0*fem, 30*fem),
              child: Text(
                'FORGOT PASSWORD',
                style: SafeGoogleFont (
                  'Poppins',
                  fontSize: 12*ffem,
                  fontWeight: FontWeight.w700,
                  height: 1.5*ffem/fem,
                  letterSpacing: 2*fem,
                  color: Color(0xff7e7e7e),
                ),
              ),
            ),
            Container(
              // undrawforgotpasswordgi2d1heY (8:606)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 1*fem, 284*fem),
              width: 200*fem,
              height: 148.01*fem,
              child: Image.asset(
                'assets/light/images/undrawforgotpasswordgi2d-1.png',
                width: 200*fem,
                height: 148.01*fem,
              ),
            ),
            Container(
              // autogroupmb9jMj6 (VPEcAATLUwpi7bxXC7MB9J)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 50*fem),
              width: double.infinity,
              height: 48*fem,
              child: Stack(
                children: [
                  Positioned(
                    // logintDE (8:506)
                    left: 25*fem,
                    top: 0*fem,
                    child: Align(
                      child: SizedBox(
                        width: 40*fem,
                        height: 15*fem,
                        child: Text(
                          'EMAIL',
                          textAlign: TextAlign.center,
                          style: SafeGoogleFont (
                            'Poppins',
                            fontSize: 10*ffem,
                            fontWeight: FontWeight.w700,
                            height: 1.5*ffem/fem,
                            letterSpacing: 2*fem,
                            color: Color(0xff7e7e7e),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // subtractmXv (8:511)
                    left: 0*fem,
                    top: 8*fem,
                    child: Align(
                      child: SizedBox(
                        width: 335*fem,
                        height: 40*fem,
                        child: Image.asset(
                          'assets/light/images/subtract-fse.png',
                          width: 335*fem,
                          height: 40*fem,
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // useremailcomHmA (8:514)
                    left: 26*fem,
                    top: 17.5*fem,
                    child: Align(
                      child: SizedBox(
                        width: 126*fem,
                        height: 21*fem,
                        child: Text(
                          'user@email.com',
                          style: SafeGoogleFont (
                            'Poppins',
                            fontSize: 14*ffem,
                            fontWeight: FontWeight.w400,
                            height: 1.5*ffem/fem,
                            letterSpacing: 0.5*fem,
                            color: Color(0xff000000),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogrouprxdak8x (VPEcFF9CnwMMJncvWJRXDA)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 55*fem),
              width: double.infinity,
              height: 40*fem,
              decoration: BoxDecoration (
                color: Color(0xff000000),
                borderRadius: BorderRadius.circular(5*fem),
              ),
              child: Center(
                child: Center(
                  child: Text(
                    'Send Link',
                    textAlign: TextAlign.center,
                    style: SafeGoogleFont (
                      'Poppins',
                      fontSize: 12*ffem,
                      fontWeight: FontWeight.w500,
                      height: 1.5*ffem/fem,
                      letterSpacing: 2*fem,
                      color: Color(0xffffffff),
                    ),
                  ),
                ),
              ),
            ),
            Container(
              // arrowleftBk4 (8:654)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 1*fem, 0*fem),
              width: 14*fem,
              height: 14*fem,
              child: Image.asset(
                'assets/light/images/arrow-left.png',
                width: 14*fem,
                height: 14*fem,
              ),
            ),
          ],
        ),
      ),
          );
  }
}