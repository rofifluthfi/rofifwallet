import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 375;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // login4Ki (8:236)
        padding: EdgeInsets.fromLTRB(20*fem, 70*fem, 20*fem, 54.5*fem),
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xffffffff),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // loginLHE (8:315)
              margin: EdgeInsets.fromLTRB(2*fem, 0*fem, 0*fem, 30*fem),
              child: Text(
                'LOGIN',
                style: SafeGoogleFont (
                  'Poppins',
                  fontSize: 12*ffem,
                  fontWeight: FontWeight.w700,
                  height: 1.5*ffem/fem,
                  letterSpacing: 2*fem,
                  color: Color(0xff7e7e7e),
                ),
              ),
            ),
            Container(
              // undrawsecureloginpdn41DM2 (8:339)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 1*fem, 128*fem),
              width: 200*fem,
              height: 139*fem,
              child: Image.asset(
                'assets/light/images/undrawsecureloginpdn4-1.png',
                width: 200*fem,
                height: 139*fem,
              ),
            ),
            Container(
              // autogroupyxbz5e8 (VPEatT5ALqMa2EPHBZyxbz)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 22*fem),
              width: double.infinity,
              height: 48*fem,
              child: Stack(
                children: [
                  Positioned(
                    // loginb6g (8:321)
                    left: 25*fem,
                    top: 0*fem,
                    child: Align(
                      child: SizedBox(
                        width: 40*fem,
                        height: 15*fem,
                        child: Text(
                          'EMAIL',
                          textAlign: TextAlign.center,
                          style: SafeGoogleFont (
                            'Poppins',
                            fontSize: 10*ffem,
                            fontWeight: FontWeight.w700,
                            height: 1.5*ffem/fem,
                            letterSpacing: 2*fem,
                            color: Color(0xff7e7e7e),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // subtractHEQ (8:325)
                    left: 0*fem,
                    top: 8*fem,
                    child: Align(
                      child: SizedBox(
                        width: 335*fem,
                        height: 40*fem,
                        child: Image.asset(
                          'assets/light/images/subtract-Qpp.png',
                          width: 335*fem,
                          height: 40*fem,
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // useremailcombVz (8:326)
                    left: 26*fem,
                    top: 17.5*fem,
                    child: Align(
                      child: SizedBox(
                        width: 126*fem,
                        height: 21*fem,
                        child: Text(
                          'user@email.com',
                          style: SafeGoogleFont (
                            'Poppins',
                            fontSize: 14*ffem,
                            fontWeight: FontWeight.w400,
                            height: 1.5*ffem/fem,
                            letterSpacing: 0.5*fem,
                            color: Color(0xff000000),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroupngh6H7v (VPEb27X4T3xNcDMJ7dNgH6)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 14*fem),
              width: double.infinity,
              height: 72*fem,
              child: Stack(
                children: [
                  Positioned(
                    // loginCVn (8:327)
                    left: 22.5*fem,
                    top: 8*fem,
                    child: Align(
                      child: SizedBox(
                        width: 75*fem,
                        height: 15*fem,
                        child: Text(
                          'PASSWORD',
                          textAlign: TextAlign.center,
                          style: SafeGoogleFont (
                            'Poppins',
                            fontSize: 10*ffem,
                            fontWeight: FontWeight.w700,
                            height: 1.5*ffem/fem,
                            letterSpacing: 2*fem,
                            color: Color(0xff7e7e7e),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // 5Za (8:331)
                    left: 23*fem,
                    top: 0*fem,
                    child: Align(
                      child: SizedBox(
                        width: 75*fem,
                        height: 72*fem,
                        child: Text(
                          '·······',
                          style: SafeGoogleFont (
                            'Poppins',
                            fontSize: 48*ffem,
                            fontWeight: FontWeight.w400,
                            height: 1.5*ffem/fem,
                            letterSpacing: 0.5*fem,
                            color: Color(0xff000000),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // subtractmSQ (8:336)
                    left: 0*fem,
                    top: 16*fem,
                    child: Align(
                      child: SizedBox(
                        width: 335*fem,
                        height: 40*fem,
                        child: Image.asset(
                          'assets/light/images/subtract-tg8.png',
                          width: 335*fem,
                          height: 40*fem,
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // eyetX2 (8:841)
                    left: 297.75*fem,
                    top: 30*fem,
                    child: Align(
                      child: SizedBox(
                        width: 16.5*fem,
                        height: 12*fem,
                        child: Image.asset(
                          'assets/light/images/eye-ApQ.png',
                          width: 16.5*fem,
                          height: 12*fem,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // forgotpasswordQVN (8:337)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 30*fem),
              child: Text(
                'Forgot Password',
                style: SafeGoogleFont (
                  'Poppins',
                  fontSize: 10*ffem,
                  fontWeight: FontWeight.w400,
                  height: 1.5*ffem/fem,
                  letterSpacing: 0.5*fem,
                  color: Color(0xff7e7e7e),
                ),
              ),
            ),
            Container(
              // autogroupmpxcVFv (VPEb9mxxZGZBCCKK3gmPxC)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 50*fem),
              width: double.infinity,
              height: 40*fem,
              decoration: BoxDecoration (
                color: Color(0xff000000),
                borderRadius: BorderRadius.circular(5*fem),
              ),
              child: Center(
                child: Center(
                  child: Text(
                    'Login',
                    textAlign: TextAlign.center,
                    style: SafeGoogleFont (
                      'Poppins',
                      fontSize: 12*ffem,
                      fontWeight: FontWeight.w500,
                      height: 1.5*ffem/fem,
                      letterSpacing: 2*fem,
                      color: Color(0xffffffff),
                    ),
                  ),
                ),
              ),
            ),
            Center(
              // donthaveanaccountyetregister9L (8:338)
              child: Container(
                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 1*fem, 54.5*fem),
                child: RichText(
                  textAlign: TextAlign.center,
                  text: TextSpan(
                    style: SafeGoogleFont (
                      'Poppins',
                      fontSize: 12*ffem,
                      fontWeight: FontWeight.w500,
                      height: 1.5*ffem/fem,
                      letterSpacing: 1*fem,
                      color: Color(0xff000000),
                    ),
                    children: [
                      TextSpan(
                        text: 'Don’t have an account yet?',
                        style: SafeGoogleFont (
                          'Poppins',
                          fontSize: 12*ffem,
                          fontWeight: FontWeight.w500,
                          height: 1.5*ffem/fem,
                          letterSpacing: 1*fem,
                          color: Color(0xff7e7e7e),
                        ),
                      ),
                      TextSpan(
                        text: ' ',
                        style: SafeGoogleFont (
                          'Poppins',
                          fontSize: 12*ffem,
                          fontWeight: FontWeight.w500,
                          height: 1.5*ffem/fem,
                          letterSpacing: 1*fem,
                          color: Color(0xff000000),
                        ),
                      ),
                      TextSpan(
                        text: 'Register',
                        style: SafeGoogleFont (
                          'Poppins',
                          fontSize: 12*ffem,
                          fontWeight: FontWeight.w700,
                          height: 1.5*ffem/fem,
                          letterSpacing: 1*fem,
                          color: Color(0xff000000),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            Container(
              // xTGc (8:317)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 1*fem, 0*fem),
              width: 9*fem,
              height: 9*fem,
              child: Image.asset(
                'assets/light/images/x-odA.png',
                width: 9*fem,
                height: 9*fem,
              ),
            ),
          ],
        ),
      ),
          );
  }
}