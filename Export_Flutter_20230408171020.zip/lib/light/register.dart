import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 375;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // registerFex (8:368)
        padding: EdgeInsets.fromLTRB(20*fem, 70*fem, 20*fem, 54.5*fem),
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xffffffff),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // loginkLp (8:371)
              margin: EdgeInsets.fromLTRB(3*fem, 0*fem, 0*fem, 30*fem),
              child: Text(
                'REGISTER',
                style: SafeGoogleFont (
                  'Poppins',
                  fontSize: 12*ffem,
                  fontWeight: FontWeight.w700,
                  height: 1.5*ffem/fem,
                  letterSpacing: 2*fem,
                  color: Color(0xff7e7e7e),
                ),
              ),
            ),
            Container(
              // undrawauthenticationfsn5146c (8:418)
              margin: EdgeInsets.fromLTRB(1*fem, 0*fem, 0*fem, 154.01*fem),
              width: 200*fem,
              height: 137.99*fem,
              child: Image.asset(
                'assets/light/images/undrawauthenticationfsn5-1.png',
                width: 200*fem,
                height: 137.99*fem,
              ),
            ),
            Container(
              // autogroupslw4HEG (VPEbaBRxhipC3AHQY7SLW4)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 22*fem),
              width: double.infinity,
              height: 48*fem,
              child: Stack(
                children: [
                  Positioned(
                    // loginc1e (8:372)
                    left: 25*fem,
                    top: 0*fem,
                    child: Align(
                      child: SizedBox(
                        width: 40*fem,
                        height: 15*fem,
                        child: Text(
                          'EMAIL',
                          textAlign: TextAlign.center,
                          style: SafeGoogleFont (
                            'Poppins',
                            fontSize: 10*ffem,
                            fontWeight: FontWeight.w700,
                            height: 1.5*ffem/fem,
                            letterSpacing: 2*fem,
                            color: Color(0xff7e7e7e),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // subtract6hW (8:377)
                    left: 0*fem,
                    top: 8*fem,
                    child: Align(
                      child: SizedBox(
                        width: 335*fem,
                        height: 40*fem,
                        child: Image.asset(
                          'assets/light/images/subtract-byA.png',
                          width: 335*fem,
                          height: 40*fem,
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // useremailcomCEk (8:380)
                    left: 26*fem,
                    top: 17.5*fem,
                    child: Align(
                      child: SizedBox(
                        width: 126*fem,
                        height: 21*fem,
                        child: Text(
                          'user@email.com',
                          style: SafeGoogleFont (
                            'Poppins',
                            fontSize: 14*ffem,
                            fontWeight: FontWeight.w400,
                            height: 1.5*ffem/fem,
                            letterSpacing: 0.5*fem,
                            color: Color(0xff000000),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroupd3vgVUk (VPEbiG2qEEVQbCyZ5td3vG)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 34*fem),
              width: double.infinity,
              height: 72*fem,
              child: Stack(
                children: [
                  Positioned(
                    // logind5A (8:373)
                    left: 22.5*fem,
                    top: 8*fem,
                    child: Align(
                      child: SizedBox(
                        width: 75*fem,
                        height: 15*fem,
                        child: Text(
                          'PASSWORD',
                          textAlign: TextAlign.center,
                          style: SafeGoogleFont (
                            'Poppins',
                            fontSize: 10*ffem,
                            fontWeight: FontWeight.w700,
                            height: 1.5*ffem/fem,
                            letterSpacing: 2*fem,
                            color: Color(0xff7e7e7e),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // Kig (8:381)
                    left: 23*fem,
                    top: 0*fem,
                    child: Align(
                      child: SizedBox(
                        width: 75*fem,
                        height: 72*fem,
                        child: Text(
                          '·······',
                          style: SafeGoogleFont (
                            'Poppins',
                            fontSize: 48*ffem,
                            fontWeight: FontWeight.w400,
                            height: 1.5*ffem/fem,
                            letterSpacing: 0.5*fem,
                            color: Color(0xff000000),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // subtractbAQ (8:382)
                    left: 0*fem,
                    top: 16*fem,
                    child: Align(
                      child: SizedBox(
                        width: 335*fem,
                        height: 40*fem,
                        child: Image.asset(
                          'assets/light/images/subtract-BTn.png',
                          width: 335*fem,
                          height: 40*fem,
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // eye7Pe (8:844)
                    left: 297.75*fem,
                    top: 30*fem,
                    child: Align(
                      child: SizedBox(
                        width: 16.5*fem,
                        height: 12*fem,
                        child: Image.asset(
                          'assets/light/images/eye-Fua.png',
                          width: 16.5*fem,
                          height: 12*fem,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroupcbwgRv8 (VPEbpkr1N2UesQi16LCBWg)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 50*fem),
              width: double.infinity,
              height: 40*fem,
              decoration: BoxDecoration (
                color: Color(0xff000000),
                borderRadius: BorderRadius.circular(5*fem),
              ),
              child: Center(
                child: Center(
                  child: Text(
                    'Register',
                    textAlign: TextAlign.center,
                    style: SafeGoogleFont (
                      'Poppins',
                      fontSize: 12*ffem,
                      fontWeight: FontWeight.w500,
                      height: 1.5*ffem/fem,
                      letterSpacing: 2*fem,
                      color: Color(0xffffffff),
                    ),
                  ),
                ),
              ),
            ),
            Center(
              // registeredalreadyloginu4c (8:388)
              child: Container(
                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 1*fem, 54.5*fem),
                child: RichText(
                  textAlign: TextAlign.center,
                  text: TextSpan(
                    style: SafeGoogleFont (
                      'Poppins',
                      fontSize: 12*ffem,
                      fontWeight: FontWeight.w500,
                      height: 1.5*ffem/fem,
                      letterSpacing: 1*fem,
                      color: Color(0xff000000),
                    ),
                    children: [
                      TextSpan(
                        text: 'Registered already?',
                        style: SafeGoogleFont (
                          'Poppins',
                          fontSize: 12*ffem,
                          fontWeight: FontWeight.w500,
                          height: 1.5*ffem/fem,
                          letterSpacing: 1*fem,
                          color: Color(0xff7e7e7e),
                        ),
                      ),
                      TextSpan(
                        text: ' ',
                        style: SafeGoogleFont (
                          'Poppins',
                          fontSize: 12*ffem,
                          fontWeight: FontWeight.w500,
                          height: 1.5*ffem/fem,
                          letterSpacing: 1*fem,
                          color: Color(0xff000000),
                        ),
                      ),
                      TextSpan(
                        text: 'Login',
                        style: SafeGoogleFont (
                          'Poppins',
                          fontSize: 12*ffem,
                          fontWeight: FontWeight.w700,
                          height: 1.5*ffem/fem,
                          letterSpacing: 1*fem,
                          color: Color(0xff000000),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            Container(
              // x3Te (8:374)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 1*fem, 0*fem),
              width: 9*fem,
              height: 9*fem,
              child: Image.asset(
                'assets/light/images/x-LRE.png',
                width: 9*fem,
                height: 9*fem,
              ),
            ),
          ],
        ),
      ),
          );
  }
}