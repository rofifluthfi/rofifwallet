import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 375;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // homer1N (8:856)
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xffffffff),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // autogroup3awsPX6 (VPEejfzYre948fjfHo3awS)
              padding: EdgeInsets.fromLTRB(0*fem, 50*fem, 0*fem, 135*fem),
              width: double.infinity,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // cash6wJ (8:857)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 1*fem, 14*fem),
                    child: Text(
                      'CASH',
                      textAlign: TextAlign.center,
                      style: SafeGoogleFont (
                        'Poppins',
                        fontSize: 12*ffem,
                        fontWeight: FontWeight.w700,
                        height: 1.5*ffem/fem,
                        letterSpacing: 1*fem,
                        color: Color(0xff000000),
                      ),
                    ),
                  ),
                  Container(
                    // chevrondownCUY (8:858)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 1*fem, 59*fem),
                    width: 12*fem,
                    height: 6*fem,
                    child: Image.asset(
                      'assets/light/images/chevron-down.png',
                      width: 12*fem,
                      height: 6*fem,
                    ),
                  ),
                  Container(
                    // 6K2 (8:860)
                    margin: EdgeInsets.fromLTRB(1*fem, 0*fem, 0*fem, 50*fem),
                    child: Text(
                      '\$ 1,452.83',
                      style: SafeGoogleFont (
                        'Poppins',
                        fontSize: 48*ffem,
                        fontWeight: FontWeight.w700,
                        height: 1.5*ffem/fem,
                        letterSpacing: 0.5*fem,
                        color: Color(0xff000000),
                      ),
                    ),
                  ),
                  Container(
                    // autogroupajvaQKi (VPEdXNgMMLtuNDvJ8ZajVa)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 2*fem, 50*fem),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // novemberw4k (8:928)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 70*fem, 0*fem),
                          child: Text(
                            'NOVEMBER',
                            textAlign: TextAlign.right,
                            style: SafeGoogleFont (
                              'Poppins',
                              fontSize: 14*ffem,
                              fontWeight: FontWeight.w700,
                              height: 1.5*ffem/fem,
                              letterSpacing: 1*fem,
                              color: Color(0xff7e7e7e),
                            ),
                          ),
                        ),
                        Container(
                          // decembervqn (8:875)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 69*fem, 0*fem),
                          child: Text(
                            'DECEMBER',
                            style: SafeGoogleFont (
                              'Poppins',
                              fontSize: 14*ffem,
                              fontWeight: FontWeight.w700,
                              height: 1.5*ffem/fem,
                              letterSpacing: 1*fem,
                              color: Color(0xff000000),
                            ),
                          ),
                        ),
                        Text(
                          // january2dv (8:929)
                          'JANUARY',
                          style: SafeGoogleFont (
                            'Poppins',
                            fontSize: 14*ffem,
                            fontWeight: FontWeight.w700,
                            height: 1.5*ffem/fem,
                            letterSpacing: 1*fem,
                            color: Color(0xff7e7e7e),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // decMgC (8:880)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 261*fem, 20*fem),
                    child: Text(
                      '26 Dec',
                      style: SafeGoogleFont (
                        'Poppins',
                        fontSize: 14*ffem,
                        fontWeight: FontWeight.w700,
                        height: 1.5*ffem/fem,
                        letterSpacing: 1*fem,
                        color: Color(0xff7e7e7e),
                      ),
                    ),
                  ),
                  Container(
                    // autogroupgeslqbN (VPEdgsQXhf2j1HgVNbGESL)
                    margin: EdgeInsets.fromLTRB(35*fem, 0*fem, 31*fem, 20*fem),
                    width: double.infinity,
                    height: 45*fem,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // arrowdownMpc (8:881)
                          margin: EdgeInsets.fromLTRB(0*fem, 1*fem, 35*fem, 0*fem),
                          width: 14*fem,
                          height: 14*fem,
                          child: Image.asset(
                            'assets/light/images/arrow-down-Wdv.png',
                            width: 14*fem,
                            height: 14*fem,
                          ),
                        ),
                        Container(
                          // autogroupzk9nfqJ (VPEdq7fno5wJkAGHmTZk9n)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 108*fem, 0*fem),
                          height: double.infinity,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                // Q2C (8:878)
                                '\$ 12.35',
                                style: SafeGoogleFont (
                                  'Poppins',
                                  fontSize: 18*ffem,
                                  fontWeight: FontWeight.w700,
                                  height: 1.5*ffem/fem,
                                  letterSpacing: 1*fem,
                                  color: Color(0xff000000),
                                ),
                              ),
                              Text(
                                // breakfastcoffeejqA (8:879)
                                'Breakfast & Coffee',
                                style: SafeGoogleFont (
                                  'Poppins',
                                  fontSize: 12*ffem,
                                  fontWeight: FontWeight.w500,
                                  height: 1.5*ffem/fem,
                                  letterSpacing: 1*fem,
                                  color: Color(0xff7e7e7e),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          // coffeesAg (8:890)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 1*fem),
                          width: 21*fem,
                          height: 20*fem,
                          child: Image.asset(
                            'assets/light/images/coffee.png',
                            width: 21*fem,
                            height: 20*fem,
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // autogroupdekxP92 (VPEdyrvDbGXz3WX3hbDekx)
                    margin: EdgeInsets.fromLTRB(35*fem, 0*fem, 34*fem, 50*fem),
                    width: double.infinity,
                    height: 45*fem,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // arrowdownHEQ (8:887)
                          margin: EdgeInsets.fromLTRB(0*fem, 1*fem, 35*fem, 0*fem),
                          width: 14*fem,
                          height: 14*fem,
                          child: Image.asset(
                            'assets/light/images/arrow-down-DG4.png',
                            width: 14*fem,
                            height: 14*fem,
                          ),
                        ),
                        Container(
                          // autogrouptyoeoiY (VPEe6cDyaSNH6x5yUfTyoE)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 86*fem, 0*fem),
                          height: double.infinity,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                // YAL (8:885)
                                '\$ 63.24',
                                style: SafeGoogleFont (
                                  'Poppins',
                                  fontSize: 18*ffem,
                                  fontWeight: FontWeight.w700,
                                  height: 1.5*ffem/fem,
                                  letterSpacing: 1*fem,
                                  color: Color(0xff000000),
                                ),
                              ),
                              Text(
                                // thebookofworldHNp (8:886)
                                '1. The Book of World ...',
                                style: SafeGoogleFont (
                                  'Poppins',
                                  fontSize: 12*ffem,
                                  fontWeight: FontWeight.w500,
                                  height: 1.5*ffem/fem,
                                  letterSpacing: 1*fem,
                                  color: Color(0xff7e7e7e),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          // bookRE8 (8:896)
                          margin: EdgeInsets.fromLTRB(0*fem, 1*fem, 0*fem, 0*fem),
                          width: 16*fem,
                          height: 20*fem,
                          child: Image.asset(
                            'assets/light/images/book.png',
                            width: 16*fem,
                            height: 20*fem,
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // decwyA (8:903)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 261*fem, 20*fem),
                    child: Text(
                      '25 Dec',
                      style: SafeGoogleFont (
                        'Poppins',
                        fontSize: 14*ffem,
                        fontWeight: FontWeight.w700,
                        height: 1.5*ffem/fem,
                        letterSpacing: 1*fem,
                        color: Color(0xff7e7e7e),
                      ),
                    ),
                  ),
                  Container(
                    // autogroup167a53n (VPEeFBp1ohjbDUT5Zi167A)
                    margin: EdgeInsets.fromLTRB(35*fem, 0*fem, 32*fem, 0*fem),
                    width: double.infinity,
                    height: 45*fem,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // arrowdownB6p (8:904)
                          margin: EdgeInsets.fromLTRB(0*fem, 1*fem, 35*fem, 0*fem),
                          width: 14*fem,
                          height: 14*fem,
                          child: Image.asset(
                            'assets/light/images/arrow-down-Vqr.png',
                            width: 14*fem,
                            height: 14*fem,
                          ),
                        ),
                        Container(
                          // autogroupfr9sHvY (VPEeMw7mnsZtGv21LnFR9S)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 130*fem, 0*fem),
                          height: double.infinity,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                // QVN (8:899)
                                '\$ 100.00',
                                style: SafeGoogleFont (
                                  'Poppins',
                                  fontSize: 18*ffem,
                                  fontWeight: FontWeight.w700,
                                  height: 1.5*ffem/fem,
                                  letterSpacing: 1*fem,
                                  color: Color(0xff000000),
                                ),
                              ),
                              Text(
                                // christmasgifts9C4 (8:901)
                                'Christmas Gifts',
                                style: SafeGoogleFont (
                                  'Poppins',
                                  fontSize: 12*ffem,
                                  fontWeight: FontWeight.w500,
                                  height: 1.5*ffem/fem,
                                  letterSpacing: 1*fem,
                                  color: Color(0xff7e7e7e),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          // gift5bW (8:919)
                          margin: EdgeInsets.fromLTRB(0*fem, 1*fem, 0*fem, 0*fem),
                          width: 20*fem,
                          height: 20*fem,
                          child: Image.asset(
                            'assets/light/images/gift-gSU.png',
                            width: 20*fem,
                            height: 20*fem,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroupsjr2o1i (VPEeVvtT2vdREYmKy1sjR2)
              padding: EdgeInsets.fromLTRB(52*fem, 16*fem, 54*fem, 16*fem),
              width: double.infinity,
              decoration: BoxDecoration (
                color: Color(0xffffffff),
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // activityWwi (8:865)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 107*fem, 0*fem),
                    width: 20*fem,
                    height: 18*fem,
                    child: Image.asset(
                      'assets/light/images/activity-M4c.png',
                      width: 20*fem,
                      height: 18*fem,
                    ),
                  ),
                  Container(
                    // plussquare29N (8:867)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 108*fem, 0*fem),
                    width: 18*fem,
                    height: 18*fem,
                    child: Image.asset(
                      'assets/light/images/plus-square-boE.png',
                      width: 18*fem,
                      height: 18*fem,
                    ),
                  ),
                  Container(
                    // barchart2LQx (8:871)
                    width: 16*fem,
                    height: 12*fem,
                    child: Image.asset(
                      'assets/light/images/bar-chart-2-E6k.png',
                      width: 16*fem,
                      height: 12*fem,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
          );
  }
}